from sys import argv
file_name, hours, solaru, bonus = argv

print(float(hours) * float(solaru) * float(bonus))
