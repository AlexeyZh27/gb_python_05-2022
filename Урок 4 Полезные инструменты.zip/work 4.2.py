my_st = [300, 2, 12, 44, 1, 1, 4, 10, 7, 1, 78, 123, 555]
new_st = []

for i in range(1, len(my_st)):
    if my_st[i] > my_st[i-1]:
        new_st.append(my_st[i])

new_st_gen = [el for num, el in enumerate(my_st)if num >= 1 and my_st[num - 1] < el]

print("my_st", my_st)
print('new_st', new_st)
print('new_st_gen', new_st_gen)